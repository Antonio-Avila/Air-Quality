# This app is meant to run as a dashboard for my Air Quality Index Dashboard. 

library(shiny)
library(tidyverse)
library(usmap)
library(plotly)
library(DT)


#------------- Begin by importing data and preprocessing
ozone_texas <- read_csv("ozone_texas.csv")
ozone_texas["fips"] <- as.integer(ozone_texas$state_code) * 1000 + as.integer(ozone_texas$county_code)
counties <- unique(ozone_texas$county)

# Define functions to calculate the 8-hour maximum as per EPA ozone standard.
avg_8hr <- function(data){
  avgs = matrix(nrow = 24-8, ncol = 1)
  for(i in 1:(24-8)) { 
    avgs[i] = mean(data[i:(i+7)], na.rm = TRUE)
  }
  return(avgs)
}

max_8hr_avg <- function(data){
  max_avg = max(avg_8hr(data)) * 1000
  max_avg = trunc(max_avg)
  return(max_avg)
}


daily_max_sites <- ozone_texas %>% 
  group_by(county, fips, site_number, date_local) %>% 
  summarize(max_8hr_avg = max_8hr_avg(sample_measurement)) %>% ungroup()

daily_max_counties <- daily_max_sites %>%
  group_by(county, fips, date_local) %>% 
  summarise(county_max = suppressWarnings(max(max_8hr_avg, na.rm = TRUE))) %>% ungroup()
daily_max_counties[is.infinite(daily_max_counties$county_max),]$county_max <- NA


county_df <- us_map("county") %>% filter(full == "Texas") %>% rename(state = full)
county_df$county <- str_replace(county_df$county, " County", "")

# Define UI 
ui <- fluidPage(
  
  titlePanel("Texas Air Quality"),

  tabsetPanel(type = "tabs",
              tabPanel("Heat Map",
                       sidebarPanel(width = 3,
                             helpText("The dashboard is meant to display the levels of select pollutants in Texas in a heat map to determine the severity,
                                      or safety(?), of the quality of air. By clicking on the tab above, it will display the trends for the last 4 years.
                                     Note, for ozone levels, it displays the 8-hour maximum over the day. In addition, due to the limited number of sites
                                     in Texas that collect air quality data, the majority of counties in Texas do not report pollutant levels."),
                             
                             selectInput("pollutant", h3("Select Pollutant"), choices = list("Ozone", "PM2.5"), selected = "Ozone"),
                             dateInput("date", "Select Date", value = as.Date("2017-09-01"), min = as.Date("2017-09-01"), max = as.Date("2021-08-31")),
                                     ),
                       
                       mainPanel(
                         plotlyOutput("map")
                                 )
                       
                       ),
              
              tabPanel("Trend Plot", 
                       sidebarPanel(width = 3,
                         selectInput("pollutant", h3("Select Pollutant"), choices = list("Ozone", "PM2.5"), selected = "Ozone"),
                         selectInput("county", h3("Select County"), choices = counties, selected = "Harris"),
                         
                                  ),
                         mainPanel(
                           plotlyOutput("plot"), 
                           )
                        ),
              
              tabPanel("Data", 
                       dataTableOutput("ozone_violations"),
                       dataTableOutput("violation_times")
                       )
                       
              )
              
)



# Define server 
server <- function(input, output, session) {

  dataInput <- reactive({
    ozone_texas %>% filter(parameter == input$pollutant)
  })


  output$map <- renderPlotly({
    test_day <- daily_max_counties %>% filter(date_local == input$date)
    county_df <- left_join(county_df, test_day, by = "county")
    
    p <- plot_usmap(include = "TX") +
            geom_polygon(data = county_df, color = "black",
                         aes(x = x, y = y, group = group, fill = county_max,
                              text = paste("County:", county, "<br>Ozone:", county_max))) +
            scale_fill_gradient2(low = "green", high = "red", midpoint = 75, mid = "#ff9200", limit = c(0, 120)) +
            labs(fill = paste(input$pollutant, "Level"), title = paste(input$pollutant, "Levels on", input$date))
    width <- session$clientData$output_map_width
    ggplotly(p, tooltip = "text", height = 800, width = width)
  })



  output$plot <- renderPlotly({

    p <- daily_max_counties %>% filter(county == input$county) %>%
      ggplot(aes(date_local, county_max)) +
      geom_line(aes(color="8-Hr Max Avg Ozone")) +
      geom_hline(yintercept = 70, color = "red") +
      geom_smooth(method = "gam", se = FALSE, aes(color = "Trend")) +
      ggtitle( paste(input$county, "County Ozone levels 2017-2021") ) +
      xlab("Date") +
      ylab("Ozone 8-Hr Max (ppb)") +
      annotate("text", x = as.Date("2018-01-01"), y = 71, label = "Unhealthy Level") +
      scale_color_manual(name = "Legend", values = c("#69b3a2", "purple"))
      ggplotly(p, dynamicTicks = TRUE, height = 500) %>%  layout(hovermode = "x") %>% rangeslider()

  })


  output$ozone_violations <- renderDataTable({
    daily_max_counties %>% filter(county == input$county) %>%
      mutate(year = year(date_local)) %>% group_by(county, year) %>%
      summarize(number_unhealthy_days = sum(county_max >= 70)) %>%
      ungroup() %>% group_by(county) %>% mutate(total_violations = sum(number_unhealthy_days)) %>% 
      ungroup() %>% select(year, number_unhealthy_days, total_violations)
  })

  output$violation_times <- renderDataTable({
    daily_max_counties %>% filter(county == input$county, (county_max >= 70)) %>% select(date_local, county_max)
  })


    
}

# Run the application 
shinyApp(ui = ui, server = server)
